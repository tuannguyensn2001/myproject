<?php
    $content=$_POST['content'];
    echo $content;
    
    ?>